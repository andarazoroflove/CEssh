CEssh v0.9a for Palm T|X and Palm OS Garnet 5.4.9
=================================================

Installation options:
1. SD / CompactFlash Card:
   Copy the 'Palm' folder onto the root of your SD card:
   /Palm/Launcher/CEssh.prc
   Insert card into your Palm T|X - CEssh appears in your launcher.

2. Palm Desktop / HotSync:
   Use Palm Desktop Install Tool or QuickInstall to install CEssh.prc
   during your next HotSync.

Features:
- Pure SSH-2 client: Curve25519 Key Exchange, AES-128-CTR encryption,
  HMAC-SHA2-256 integrity, BearSSL crypto engine.
- Wi-Fi and NetLib integration for instant connectivity on Palm T|X.
- Full ANSI terminal screen emulator with Graffiti text entry,
  on-screen keyboard, and 5-way navigator support.
- Built-in commands:
  - ssh <host> [user] [pass]
  - ping <host>
  - clear
  - help
  - exit

Keyboard Shortcuts:
- Ctrl+] or Menu -> Disconnect: Disconnect active SSH session.
- Menu -> Clear Screen: Clear terminal screen.
